<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserRight extends Model
{
    //
}
