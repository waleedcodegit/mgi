<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChangeAdsImage extends Model
{
    protected $table = "ads_banners";
}
