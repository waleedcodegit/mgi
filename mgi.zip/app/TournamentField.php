<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TournamentField extends Model
{
    protected $table = "tournament_fields";
}
