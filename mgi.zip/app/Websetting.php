<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Websetting extends Model
{
    //
}
