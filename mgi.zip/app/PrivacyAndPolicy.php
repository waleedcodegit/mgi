<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrivacyAndPolicy extends Model
{
    protected $table = 'privacies__and_policies';
    protected $fillable = [
    	'privacies__and_policies'
    ];
}
