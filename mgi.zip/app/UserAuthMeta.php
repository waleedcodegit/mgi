<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAuthMeta extends Model
{
    protected $table = 'user_auth_meta';
}
