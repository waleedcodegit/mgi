<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TournamentRequiredFieldUserAnswer extends Model
{
    protected $table = "tournament_field_user_answers";
}
