<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MGL - Mobile Gaming League</title>
        <meta name="csrf-tocken" content="<?php echo e(csrf_token()); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/app.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('admin/assets/bundles/bootstrap-social/bootstrap-social.css')); ?>">
            <!-- Template CSS -->
            <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/components.css')); ?>">
            <!-- Custom style CSS -->
            <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/custom.css')); ?>">
            <link rel='shortcut icon' type='image/x-icon' href='<?php echo e(asset('images/common/mgl-logo.png')); ?>' />
    </head>
    <body>
        <div id="root"></div>
        <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('admin/assets/js/app.min.js')); ?>"></script>
  <!-- JS Libraies -->
  <script src="<?php echo e(asset('admin/assets/bundles/apexcharts/apexcharts.min.js')); ?>"></script>
  <!-- Page Specific JS File -->
  <script src="<?php echo e(asset('admin/assets/js/page/index.js')); ?>"></script>
  <!-- Template JS File -->
  <script src="<?php echo e(asset('admin/assets/js/scripts.js')); ?>"></script>
  <!-- Custom JS File -->
  <script src="<?php echo e(asset('admin/assets/js/custom.js')); ?>"></script>

    </body>
</html>
<?php /**PATH C:\Users\WanGard\Documents\GitHub\mgi\resources\views/admin.blade.php ENDPATH**/ ?>