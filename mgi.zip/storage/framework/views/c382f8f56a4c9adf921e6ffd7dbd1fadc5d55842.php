<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MGL - Mobile Gaming League</title>

        <!-- Fonts -->
        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        
        
        <link rel="icon" href="<?php echo e(asset('images/common/fav-icon.png')); ?>" type="image/x-icon">
        <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/style.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/preloader-default.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('css/demo-switcher.css')); ?>" rel="stylesheet" type="text/css" />
    
        <!-- Styles -->
    </head>
    <body>
       <div id="root">
       </div>
    </body>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/library/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/library/bootstrap.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/library/fancySelect.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/header.js')); ?>"></script>
</html>
<?php /**PATH C:\Users\WanGard\Documents\GitHub\mgi\resources\views/front.blade.php ENDPATH**/ ?>