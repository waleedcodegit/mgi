<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MGL - Mobile Gaming League</title>

        <!-- Fonts -->
        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link href="https://fonts.googleapis.com/css?family=Montserrat%7COpen+Sans:700,400%7CRaleway:400,800,900" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="icon" href="<?php echo e(asset('images/common/fav-icon.png')); ?>" type="image/x-icon">
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/style.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/preloader-default.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('css/demo-switcher.css')); ?>" rel="stylesheet" type="text/css" />
    
        <!-- Styles -->
    </head>
    <body>
       <div id="root">
       </div>
    </body>
    <script type="text/javascript" src="<?php echo e(asset('js/library/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/jquery-ui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/bootstrap.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/jquery.sticky.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/jquery.jcarousel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/jcarousel.connected-carousels.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/owl.carousel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/progressbar.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/jquery.bracket.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/chartist.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/Chart.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/fancySelect.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/isotope.pkgd.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/imagesloaded.pkgd.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('js/jquery.team-coundown.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/matches-slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/header.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/matches_broadcast_listing.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/news-line.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/match_galery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/main-club-gallery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/product-slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/circle-bar.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/standings.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/shop-price-filter.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/timeseries.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/radar.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/preloader.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/diagram.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bi-polar-diagram.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/label-placement-diagram.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/donut-chart.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/animate-donut.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/advanced-smil.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/svg-path.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/pick-circle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/horizontal-bar.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/gauge-chart.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/stacked-bar.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('js/library/chartist-plugin-legend.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/chartist-plugin-threshold.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/library/chartist-plugin-pointlabels.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dev-assets/demo-switcher.js')); ?>"></script> 

<script type="text/javascript" src="<?php echo e(asset('js/treshold.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/visible.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/anchor.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/landing_carousel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/landing_sport_standings.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/twitterslider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/champions.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/landing_mainnews_slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/carousel.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/video_slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/footer_slides.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/player_test.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
</html>
<?php /**PATH C:\Users\Wangard\Documents\GitHub\mgi\resources\views/front.blade.php ENDPATH**/ ?>