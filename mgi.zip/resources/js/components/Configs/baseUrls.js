module.exports={
    img_base:'/images/',
    backend_images: '/admin/'
}