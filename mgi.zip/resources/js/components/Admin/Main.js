import React, { Component } from 'react';
import Axios from 'axios';
import ReactDOM from 'react-dom';
import {Route , BrowserRouter , Switch} from 'react-router-dom';
import Dashboard from '../Admin/Pages/Dashboard';

import CreateNews from '../Admin/Manage News_Articals/Create';
import NewsList from '../Admin/Manage News_Articals/List';
import EditNews from '../Admin/Manage News_Articals/Edit';

import Addproduct from '../Admin/Manage Store/Addproduct';
import EditProduct from '../Admin/Manage Store/EditProduct';
import ProductLists from '../Admin/Manage Store/ProductsList';
import ProductImages from '../Admin/Manage Store/ProductImages';

import CreateVideo from '../Admin/ManageVideos/Create';
import EditVideo from '../Admin/ManageVideos/Edit';
import VideosList from '../Admin/ManageVideos/List';

import OpenTickets from '../Admin/Support/List';
import ClosedTickets from '../Admin/Support/ClosedList';
import EditTicket from '../Admin/Support/Edit';

import CreateGame from '../Admin/Games/Create';
import GamesList from '../Admin/Games/List';
import EditGame from '../Admin/Games/Edit';

import SliderImages from '../Admin/Websettings/SliderImages';
import PrivacyPolicy from '../Admin/Websettings/PrivacyPolicy';
import SocialLinks from '../Admin/Websettings/SocialMedia';
import TermsConditions from '../Admin/Websettings/TermsConditions';
import CreateSubAdmins from '../Admin/SubAdmins/Create';
import EditAdmins from '../Admin/SubAdmins/Edit';
import SubAdmins from '../Admin/SubAdmins/List';
import AdminRights from '../Admin/SubAdmins/Rights';
import Games from '../Admin/Tournament/Game';
import BasicInfo from '../Admin/Tournament/BasicDetails';
import TournamentInfo from './Tournament/Index';
import TournamentList from './Tournament/List';

import CreateBanner from '../Admin/Banner/create';
import BannersList from '../Admin/Banner/list';
import EditBanner from '../Admin/Banner/Edit';

import ChangeAdsBanner from '../Admin/ManageHeaderFooterBanner/Change';


import props from 'prop-types';

class Main extends Component {
   constructor(props){
       super(props);
       this.state = {
        user:[],
        token:'',
       }     
   }
    componentDidMount(){
        let senderdat = {
            token:window.localStorage.getItem('sop256skikl')
        }
        if(this.state.token){

        }
        else{
            Axios.post('/api/admin_check_auth', senderdat).then(res => {
                if (res.data.status == 200) { 
                    this.setState({
                        user:res.data.user,
                    })
                } else {
                  window.open('/admin-login', '_self');
                }
              })
        }
           
          
    }
    render() {
        return (
            <div>
                        <Route exect path="/adminpanel/Dashboard"  component={Dashboard}></Route>
                        <Route path="/adminpanel/create-news-articles" component={CreateNews}></Route>
                        <Route path="/adminpanel/news-list" component={NewsList}></Route>
                        <Route path="/adminpanel/edit-news/:id" component={EditNews}></Route>
                        <Route path="/adminpanel/edit-product/:id" component={EditProduct}></Route>
                        <Route path="/adminpanel/product-images/:id" component={ProductImages}></Route>
                        <Route path="/adminpanel/add-product" component={Addproduct}></Route>
                        <Route path="/adminpanel/products-list" component={ProductLists}></Route>
                        <Route path="/adminpanel/add-video" component={CreateVideo}></Route>
                        <Route path="/adminpanel/videos-list" component={VideosList}></Route>
                        <Route path="/adminpanel/edit-video/:id" component={EditVideo}></Route>
                        <Route path="/adminpanel/tickets-open" component={OpenTickets}></Route>
                        <Route path="/adminpanel/tickets-closed" component={ClosedTickets}></Route>
                        <Route path="/adminpanel/edit-ticket/:id" component={EditTicket}></Route>
                        <Route path="/adminpanel/new-game" component={CreateGame}></Route>
                        <Route path="/adminpanel/games-list" component={GamesList}></Route>
                        <Route path="/adminpanel/edit-game/:id" component={EditGame}></Route>
                        <Route path="/adminpanel/slider-images" component={SliderImages}></Route>
                        <Route path="/adminpanel/privacy-policy" component={PrivacyPolicy}></Route>
                        <Route path="/adminpanel/terms-and-conditions" component={TermsConditions}></Route>
                        <Route path="/adminpanel/social-media-links" component={SocialLinks}></Route>
                        <Route path="/adminpanel/add-admin" component={CreateSubAdmins}></Route>
                        <Route path="/adminpanel/admins" component={SubAdmins}></Route>
                        <Route path="/adminpanel/edit-admin/:id" component={EditAdmins}></Route>
                        <Route path="/adminpanel/admin-rights/:id" component = {AdminRights}></Route>
                        <Route path="/adminpanel/tournament-create" component={TournamentInfo}></Route>
                        <Route path="/adminpanel/tournament-list" component={TournamentList}></Route>
                        <Route path="/adminpanel/add-banner" component={CreateBanner}></Route>
                        <Route path="/adminpanel/banners-list" component={BannersList}></Route>
                        <Route path="/adminpanel/edit-banner/:id" component={EditBanner}></Route>
                        <Route path="/adminpanel/change-ads-banner" component={ChangeAdsBanner}></Route>

                        
                        
            </div>
        );
    }
}

export default Main;