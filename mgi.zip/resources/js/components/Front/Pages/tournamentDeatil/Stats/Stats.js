import React, { Component } from 'react'

class Stats extends Component {
    render() {
        return (
            <div>
                <div className="col-md-12 col-sm-12 matches-over">
                            <h3>No Stats Available</h3>
                            </div>
            </div>
        )
    }
}
export default Stats;
