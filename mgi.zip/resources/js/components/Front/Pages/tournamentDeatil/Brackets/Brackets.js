import React, { Component } from 'react'

class Brackets extends Component {
    render() {
        return (
            <div>
                <div className="col-md-12 col-sm-12 matches-over">
                    <div className="elimnation">
                        <img src="/images/common/elmination.png" />
                    </div>
                </div>
            </div>
        )
    }
}
export default Brackets;
